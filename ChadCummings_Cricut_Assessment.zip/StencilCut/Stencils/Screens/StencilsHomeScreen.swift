//
//  StencilsHomeScreen.swift
//  StencilCut
//
//  Created by Chad Cummings on 8/28/24.
//

import Foundation
import SwiftData
import SwiftUI

struct StencilsHomeScreen: View {
    @Environment(\.modelContext) private var modelContext
    
    @Query private var stencils: [StencilModel]
    
    @State private var shapes: [ShapeModel]
    
    @State private var selectedStencil: StencilModel?
    
    init(shapes: [ShapeModel] = []) {
        self.shapes = shapes
    }
    
    var columns = [
        GridItem(.adaptive(minimum: 100), spacing: 16)
    ]
    
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVGrid(columns: columns, spacing: 16) {
                    ForEach(stencils) { stencil in
                        StencilView(stencil: stencil)
                            .scaledToFill()
                            .onTapGesture {
                                selectedStencil = stencil
                            }
                    }
                }
                .navigationDestination(item: $selectedStencil) { stencil in
                    StencilDetailScreen(stencil: stencil)
                }
            }
            .overlay {
                if stencils.isEmpty {
                    Text("Add Stencil Shapes to Begin")
                }
            }
            .padding(.horizontal, 16)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Clear All", role: .destructive, action: clearAll)
                        .disabled(stencils.isEmpty)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink {
                        StencilsEditScreen(shapeFilter: "circle")
                    } label: {
                        Text("Edit Circles")
                    }
                }
                ToolbarItemGroup(placement: .bottomBar) {
                    if shapes.isEmpty {
                        Text("Oh snap")
                    } else {
                        Button(shapes[0].name) {
                            addStencil(shape: shapes[0].drawPath)
                        }
                        Spacer()
                        Button(shapes[1].name) {
                            addStencil(shape: shapes[1].drawPath)
                        }
                        Spacer()
                        Button(shapes[2].name) {
                            addStencil(shape: shapes[2].drawPath)
                        }
                    }
                }
            }
            .refreshable {
                shapes = try! await ShapesClient.fetchShapes(id: "001")
            }
            .task {
                if shapes.isEmpty {
                    shapes = try! await ShapesClient.fetchShapes(id: "001")
                }
            }
        }
    }
    
    private func clearAll() {
        for stencil in stencils {
            modelContext.delete(stencil)
        }
    }
    
    private func addStencil(shape: String) {
        modelContext.insert(StencilModel(shape: shape))
    }
}

#Preview {
    let config = ModelConfiguration(isStoredInMemoryOnly: true)
    let container = try! ModelContainer(for: StencilModel.self, configurations: config)
    
    return StencilsHomeScreen()
    .modelContainer(container)
}
