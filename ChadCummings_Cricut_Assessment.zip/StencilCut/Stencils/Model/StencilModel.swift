//
//  Stencil.swift
//  StencilCut
//
//  Created by Chad Cummings on 8/31/24.
//

import SwiftData
import Foundation

@Model
final class StencilModel {
    let id: UUID = UUID()
    let shape: String
    
    init(shape: String) {
        self.shape = shape
    }
}

extension StencilModel: Identifiable, Hashable {}
