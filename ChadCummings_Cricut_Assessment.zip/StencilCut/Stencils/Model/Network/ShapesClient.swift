//
//  StencilsClient.swift
//  StencilCut
//
//  Created by Chad Cummings on 8/28/24.
//

import Foundation
import os

/// Corrected JSON for building purposes.
private let json =
"""
{
    "buttons": [
        {
            "name": "Circle",
            "draw_path": "circle"
        },
        {
            "name": "Square",
            "draw_path": "square"
        },
        {
            "name": "Triangle",
            "draw_path": "triangle"
        }
    ]
}
""".data(using: .utf8)!

/// Uses the ShapesApi to return data models
struct ShapesClient {
    enum ShapesClientError: Error {
        case invalidUrl
        case errorStatus
    }
    
    static func fetchShapes(id: String) async throws -> [ShapeModel] {
        let useLocalJson = true
        
        if useLocalJson {
            do {
                let dto = try JSONDecoder().decode(ButtonsDTO.self, from: json)
                return dto.buttons.map { button in
                    ShapeModel(name: button.name, drawPath: button.drawPath)
                }
            } catch {
                print(error)
                throw error
            }
        } else {
            let (data, response) = try await URLSession.shared.data(from: ShapesApi.shapes(id).url)
            
            guard let response = response as? HTTPURLResponse, response.isStatusOK() else {
                throw ShapesClientError.errorStatus
            }
            
            do {
                let dto = try JSONDecoder().decode(ButtonsDTO.self, from: data)
                return dto.buttons.map { button in
                    ShapeModel(name: button.name, drawPath: button.drawPath)
                }
            } catch {
                print(error)
                throw error
            }
        }
    }
}

extension HTTPURLResponse {
    func isStatusOK() -> Bool {
        return (200...299).contains(self.statusCode)
    }
    
    func isForwarding() -> Bool {
        return (300...399).contains(self.statusCode)
    }
    
    func isServerError() -> Bool {
        return(500...599).contains(self.statusCode)
    }
    
    func isClientError() -> Bool {
        return (400...499).contains(self.statusCode)
    }
}
